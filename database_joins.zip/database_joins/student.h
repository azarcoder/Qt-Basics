#ifndef STUDENT_H
#define STUDENT_H

#include <QMainWindow>
#include "insert.h"
#include "update.h"
#include "delete.h"

namespace Ui {
class Student;
}

class Student : public QMainWindow
{
    Q_OBJECT

public:
    explicit Student(QWidget *parent = nullptr);
    ~Student();

    Insert *m_Insert;
    Update *m_Update;
    Delete *m_Delete;

private slots:
    void on_pushButton_stu_insert_clicked();

    void on_pushButton_stu_view_clicked();

    void on_pushButton_stu_upd_clicked();

    void on_pushButton_stu_del_clicked();

private:
    Ui::Student *ui;
};

#endif // STUDENT_H
