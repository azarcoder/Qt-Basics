#ifndef UPDATE_H
#define UPDATE_H

#include <QMainWindow>

namespace Ui {
class Update;
}

class Update : public QMainWindow
{
    Q_OBJECT

public:
    explicit Update(QWidget *parent = nullptr);
    ~Update();

private:
    Ui::Update *ui;
};

#endif // UPDATE_H
