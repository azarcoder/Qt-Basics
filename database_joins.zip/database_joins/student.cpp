#include "student.h"
#include "ui_student.h"
#include "mainwindow.h"
#include <QMessageBox>
#include <QDebug>
extern MainWindow *g_Mainwindowptr;
Student::Student(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Student)
{
    ui->setupUi(this);
    m_Insert = new Insert(this);
    m_Update = new Update(this);
    m_Delete = new Delete(this);
}

Student::~Student()
{
    delete ui;
}

void Student::on_pushButton_stu_insert_clicked()
{
    m_Insert->show();
}


void Student::on_pushButton_stu_view_clicked()
{
    ui->tableWidget->clearContents();// this refresh table widget
    g_Mainwindowptr->m_DB_Connection.open();
    g_Mainwindowptr->m_DB_Connection.transaction();
    qint8 No_of_rows_to_display = 10;
    QSqlQuery query(g_Mainwindowptr->m_DB_Connection);
    query.prepare("SELECT * FROM student");
    if (query.exec()) {
        ui->tableWidget->setRowCount(No_of_rows_to_display);
        qint16 iRowCount = 0;
        while (query.next()) {
            ui->tableWidget->setItem(iRowCount, 0, new QTableWidgetItem(QString(query.value("sid").toString())));
            ui->tableWidget->setItem(iRowCount, 1, new QTableWidgetItem(QString(query.value("name").toString())));
            ui->tableWidget->setItem(iRowCount, 2, new QTableWidgetItem(QString(query.value("city").toString())));
            ui->tableWidget->setItem(iRowCount, 3, new QTableWidgetItem(QString(query.value("school_id").toString())));
            iRowCount += 1;
        }
    }
    g_Mainwindowptr->m_DB_Connection.commit();
    g_Mainwindowptr->m_DB_Connection.close();

}


void Student::on_pushButton_stu_upd_clicked()
{
    m_Update->show();
}


void Student::on_pushButton_stu_del_clicked()
{
    m_Delete->show();
}

