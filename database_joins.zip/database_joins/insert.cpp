#include "insert.h"
#include "ui_insert.h"
#include "mainwindow.h"
#include <QMessageBox>
extern MainWindow *g_Mainwindowptr;
Insert::Insert(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Insert)
{
    ui->setupUi(this);
}

Insert::~Insert()
{
    delete ui;
}

void Insert::on_pushButton_insert_clicked()
{
        g_Mainwindowptr->m_DB_Connection.open();


        g_Mainwindowptr->m_DB_Connection.transaction();

        QSqlQuery query(g_Mainwindowptr->m_DB_Connection);
        query.prepare("INSERT INTO student (name,city,school_id) VALUES(:name, :city, :school_id)");
        query.bindValue(":name",ui->lineEdit_Name->text());
        query.bindValue(":city",ui->lineEdit_City->text());
        query.bindValue(":school_id",ui->comboBox_schId->currentText().toInt());

        if (query.exec()) {
            g_Mainwindowptr->m_DB_Connection.commit();
            QMessageBox::information(this,"status","Inserted successfully!");
        }
        else {
            QMessageBox::critical(this,"Error","Inserted failed! " + query.lastError().text() );
            g_Mainwindowptr->m_DB_Connection.close();
        }
        g_Mainwindowptr->m_DB_Connection.close();
}

