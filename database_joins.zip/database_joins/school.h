#ifndef SCHOOL_H
#define SCHOOL_H

#include <QMainWindow>

namespace Ui {
class School;
}

class School : public QMainWindow
{
    Q_OBJECT

public:
    explicit School(QWidget *parent = nullptr);
    ~School();

private slots:
    void on_pushButton_viewData_clicked();
    void show_city();
    void show_sid();

private:
    Ui::School *ui;
};

#endif // SCHOOL_H
