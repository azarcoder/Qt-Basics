#include "school.h"
#include "ui_school.h"
#include<QDebug>
#include "mainwindow.h"
#include <QMessageBox>
extern MainWindow *g_Mainwindowptr;
School::School(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::School)
{
    ui->setupUi(this);
    ui->lineEdit_city->setVisible(false);
    ui->lineEdit_Schid->setVisible(false);
    connect(ui->radioButton_city,&QRadioButton::clicked,this,&School::show_city);
    connect(ui->radioButton_sid,&QRadioButton::clicked,this,&School::show_sid);
}

School::~School()
{
    delete ui;
}

void School::on_pushButton_viewData_clicked()
{
    if (ui->radioButton_city->isChecked()) {
      g_Mainwindowptr->m_DB_Connection.open();
      g_Mainwindowptr->m_DB_Connection.transaction();
      QSqlQuery query(g_Mainwindowptr->m_DB_Connection);
      query.prepare("select stu.sid,stu.name,stu.city,sch.school_name from student  as stu\
                     inner join school as sch on stu.school_id=sch.school_id\
                     where stu.city = :city;");
      query.bindValue(":city",ui->lineEdit_city->text());
    if(query.exec()) {
      g_Mainwindowptr->m_DB_Connection.commit();
      while (query.next()) {
          qDebug() << "Student id:" << query.value("sid").toString().toInt() << "Student Name:" << query.value("name").toString()
                   << "School name:" << query.value("school_name").toString();
      }
    }
    else {
      QMessageBox::critical(this,"Error","deletion failed! " + query.lastError().text() );
      g_Mainwindowptr->m_DB_Connection.close();
    }
    g_Mainwindowptr->m_DB_Connection.close();
    }

    else if(ui->radioButton_sid->isChecked()) {
        g_Mainwindowptr->m_DB_Connection.open();
        g_Mainwindowptr->m_DB_Connection.transaction();
        QSqlQuery query(g_Mainwindowptr->m_DB_Connection);
        query.prepare("select stu.sid,stu.name,stu.city,sch.school_id from student  as stu\
                       inner join school as sch on stu.school_id=sch.school_id\
                       where stu.school_id = :sch_id;");
        query.bindValue(":sch_id",ui->lineEdit_Schid->text().toInt());
      if(query.exec()) {
        g_Mainwindowptr->m_DB_Connection.commit();
        while (query.next()) {
            qDebug() << "Student id:" << query.value("sid").toString().toInt() << "Student Name:" << query.value("name").toString();
        }
      }
      else {
        QMessageBox::critical(this,"Error","deletion failed! " + query.lastError().text() );
        g_Mainwindowptr->m_DB_Connection.close();
      }
      g_Mainwindowptr->m_DB_Connection.close();
    }

}

void School::show_city()
{
    ui->lineEdit_city->setVisible(ui->radioButton_city->isChecked());
    ui->lineEdit_Schid->setVisible(false);
}

void School::show_sid()
{
    ui->lineEdit_Schid->setVisible(ui->radioButton_sid->isChecked());
     ui->lineEdit_city->setVisible(false);
}

