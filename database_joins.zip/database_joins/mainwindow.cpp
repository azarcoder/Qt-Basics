#include "mainwindow.h"
#include "ui_mainwindow.h"
MainWindow *g_Mainwindowptr;
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_Student = new Student(this);
    m_School = new School(this);

    // Create a QSqlDatabase object
    m_DB_Connection = QSqlDatabase::addDatabase("QSQLITE");
    g_Mainwindowptr = this;
    m_DB_Connection.setDatabaseName(QCoreApplication::applicationDirPath()+"student.db");
    if (m_DB_Connection.open()) {
        qDebug() << "Database connected successfully!";
    }
    else {
        qDebug() << "database is not connected";
        qDebug() << "Error : " << m_DB_Connection.lastError();
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_student_clicked()
{
    m_Student->show();
}


void MainWindow::on_pushButton_sch_clicked()
{
    m_School->show();
}

