#include "delete.h"
#include "ui_delete.h"
#include "mainwindow.h"
#include <QMessageBox>
extern MainWindow *g_Mainwindowptr;
Delete::Delete(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Delete)
{
    ui->setupUi(this);
}

Delete::~Delete()
{
    delete ui;
}

void Delete::on_pushButton_del_clicked()
{
    g_Mainwindowptr->m_DB_Connection.open();
    g_Mainwindowptr->m_DB_Connection.transaction();
    QSqlQuery query(g_Mainwindowptr->m_DB_Connection);
    query.prepare("DELETE FROM student WHERE sid=:sid");
    query.bindValue(":sid",ui->lineEdit_sid->text().toInt());
    if (query.exec()) {
        g_Mainwindowptr->m_DB_Connection.commit();
        QMessageBox::information(this,"status","deleted successfully!");
    }
    else {
        QMessageBox::critical(this,"Error","deletion failed! " + query.lastError().text() );
        g_Mainwindowptr->m_DB_Connection.close();
    }
    g_Mainwindowptr->m_DB_Connection.close();
}

