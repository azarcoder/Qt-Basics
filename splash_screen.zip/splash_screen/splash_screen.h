#ifndef SPLASH_SCREEN_H
#define SPLASH_SCREEN_H

#include <QMainWindow>

namespace Ui {
class splash_screen;
}

class splash_screen : public QMainWindow
{
    Q_OBJECT

public:
    explicit splash_screen(QWidget *parent = nullptr);
    ~splash_screen();

private:
    Ui::splash_screen *ui;
};

#endif // SPLASH_SCREEN_H
