#include "splash_screen.h"
#include "ui_splash_screen.h"

splash_screen::splash_screen(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::splash_screen)
{
    ui->setupUi(this);
}

splash_screen::~splash_screen()
{
    delete ui;
}
