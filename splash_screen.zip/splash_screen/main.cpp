#include "mainwindow.h"

#include <QApplication>
#include <QSplashScreen>
#include <QTimer>
#include <QPixmap>
#include "splash_screen.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QSplashScreen *splash = new QSplashScreen;

    QPixmap originalPixmap(":/images/aerowave splash.png");
    int16_t height = 1980;
    int16_t width = 1080;
    QPixmap scaledPixmap = originalPixmap.scaled(width, height, Qt::KeepAspectRatio);



    splash->setPixmap(scaledPixmap);
    splash->show();

    MainWindow w;
    QTimer::singleShot(3000, splash, SLOT(close()));
    QTimer::singleShot(3000, &w, &MainWindow::show);
    return a.exec();
}
